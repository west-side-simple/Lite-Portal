-- Стартовый скрипт аддона Favorit TVS WS (дополнение для TVS)
-- формирование меню обновления источников TVS по категориям
-- создание меню альтернативных категорий для избранных источников
-- author west_side 05.08.23

	if m_simpleTV.User==nil then m_simpleTV.User={} end
	if m_simpleTV.User.TVSources_fav==nil then m_simpleTV.User.TVSources_fav={} end
	if m_simpleTV.User.TVSources_fav.ini == nil then
		AddFileToExecute('onconfig', m_simpleTV.MainScriptDir .. 'user/TVSources_fav/initconfig.lua')
	end
	local function getConfigVal(key)
		return m_simpleTV.Config.GetValue(key,'TVS.ini')
	end

	local function setConfigVal(key,val)
		m_simpleTV.Config.SetValue(key,val,'TVS.ini')
	end

	local function GetInfoFromScraper(scraper)
		local path = m_simpleTV.MainScriptDir .. 'user/TVSources/scrapers/'
		local t = m_simpleTV.Common.DirectoryEntryList(path,'*.lua','Files|NoDot|NoDotDot','Name|IgnoreCase|DirsFirst')
		if t~=nil then
			for i=1,#t do
				if t[i].fileName == scraper .. '.lua' then
					local fhandle = io.open(path .. t[i].fileName, 'r')
					local answer = fhandle:read('*a')
					fhandle:close()
					return answer:match('^(.-\n.-\n.-)\n')
				end
				i = i + 1
			end
		end
		return 'нет описания'
	end

	if package.loaded['tvs_core'] and package.loaded['tvs_func'] then

		m_simpleTV.User.TVSources_fav.Enable = getConfigVal('favorites_general/TVSFavoriteWS_Enable') or 1
		m_simpleTV.User.TVSources_fav.Add = getConfigVal('favorites_general/TVSFavoriteWS_Add') or 1

		local tmp_sources = tvs_core.tvs_GetSourceParam() or {} -- загрузка списка источников из sources.lua
		local t,t0,i,k0 = {},{},1,1
		local tname
			if m_simpleTV.Interface.GetLanguage() == 'ru' then
				tname = {'Телевидение', 'Видеобиблиотека', 'Стримы', 'Аудиокниги', 'Радио', 'Платные $'} -- категории фаворитных источников (возможный вариант для сборок)
				m_simpleTV.User.TVSources_fav.str =
[[_Select">
					<option></option>
					<option>Телевидение</option>
					<option>Видеобиблиотека</option>
					<option>Стримы</option>
					<option>Аудиокниги</option>
					<option>Радио</option>
					<option>Платные $</option>
                </select>
            </td>
		    <td></td>
		</tr>]]
				m_simpleTV.User.TVSources_fav.str0 = 'Меню обновления избранных источников'
				m_simpleTV.User.TVSources_fav.str1 = 'Меню обновления TVSources'
				m_simpleTV.User.TVSources_fav.str2 = 'Избранные источники TVS'
				m_simpleTV.User.TVSources_fav.str3 = 'Все источники TVS'
				m_simpleTV.User.TVSources_fav.str4 = 'ТВ избранные источники'
				m_simpleTV.User.TVSources_fav.str5 = 'Настройки'
				m_simpleTV.User.TVSources_fav.str6 = 'Включить аддон'
				m_simpleTV.User.TVSources_fav.str7 = 'Добавить меню избранных источников'
				m_simpleTV.User.TVSources_fav.str8 =
[[Аддон позволяет упорядочить окна выбора обновления источников дополнения TVSources (автор BM).</br>В первую очередь ориентировано на присутствие в сборках SimpleTV использующих дополнение TVSources.</br>Включает меню обновления избранных плейлистов дополнения TVS по созданным авторами сборки категориям.</br>Горячая клавиша Ctrl+Shift+M.</div>
<div id="bottom">TVS Favorite addon by west_side</div></div>
</body>
</html>]]
			else
				tname = {'TV', 'VideoLibrary', 'Streams', 'Audiobooks', 'Radio', 'Paid $'}
				m_simpleTV.User.TVSources_fav.str =
[[_Select">
					<option></option>
					<option>TV</option>
					<option>VideoLibrary</option>
					<option>Streams</option>
					<option>Audiobooks</option>
					<option>Radio</option>
					<option>Paid $</option>
                </select>
            </td>
		    <td></td>
		</tr>]]
				m_simpleTV.User.TVSources_fav.str0 = 'TVS: Update favorite sources menu'
				m_simpleTV.User.TVSources_fav.str1 = 'Menu for updating TVSources'
				m_simpleTV.User.TVSources_fav.str2 = 'Favorite TVSources'
				m_simpleTV.User.TVSources_fav.str3 = 'All TVSources'
				m_simpleTV.User.TVSources_fav.str4 = 'TV Favorite Sources'
				m_simpleTV.User.TVSources_fav.str5 = 'Settings'
				m_simpleTV.User.TVSources_fav.str6 = 'On addon'
				m_simpleTV.User.TVSources_fav.str7 = 'Add favorite sources menu'
				m_simpleTV.User.TVSources_fav.str8 =
[[The addon allows you to organize the selection window for updating the sources of the TVSources addon (author BM).</br>First of all, it is focused on the presence in SimpleTV assemblies using the TVSources addon.</br>Hot button for update TVSources Ctrl+Shift+M.</div>
<div id="bottom">TVS Favorite addon by west_side</div></div>
</body>
</html>]]
			end

		for SID, v in pairs(tmp_sources) do
			local update = v.LastStart
			local TypeMedia = v.STV.TypeMedia
			local NameTypeMedia
			local Name = v.name
			local Logo = v.logo
			local scraper = v.scraper:gsub('%.lua$','')
			local desc = GetInfoFromScraper(scraper)
			if m_simpleTV.Interface.GetLanguage() == 'ru' then
				NameTypeMedia = tostring(TypeMedia):gsub('0','Каналы'):gsub('1','Файлы'):gsub('2','Записи'):gsub('3','Видеотека')
				if update > 0 then
					update = '🔄 обновление: ' .. os.date('%a %d %b %Y %H:%M', update):gsub('Jan', 'Янв'):gsub('Feb', 'Фев'):gsub('Mar', 'Мар'):gsub('Apr', 'Апр'):gsub('May', 'Май'):gsub('Jun', 'Июн'):gsub('Jul', 'Июл'):gsub('Aug', 'Авг'):gsub('Sep', 'Сен'):gsub('Oct', 'Окт'):gsub('Nov', 'Ноя'):gsub('Dec', 'Дек'):gsub('Sun', 'Вс'):gsub('Mon', 'Пн'):gsub('Tue', 'Вт'):gsub('Wed', 'Ср'):gsub('Thu', 'Чт'):gsub('Fri', 'Пт'):gsub('Sat', 'Сб')
				else
					update = '🔄 обновление не производилось'
				end
			else
				NameTypeMedia = tostring(TypeMedia):gsub('0','Channels'):gsub('1','Files'):gsub('2','Records'):gsub('3','Library')
				if update > 0 then
					update = '🔄 update: ' .. os.date('%a %d %b %Y %H:%M', update)
				else
					update = '🔄 update not produced'
				end
			end

			local isEnable = 1
			if getConfigVal('favorites/' .. SID .. '_enable') and tonumber(getConfigVal('favorites/' .. SID .. '_enable')) == 0 then
				isEnable = 0
			elseif not getConfigVal('favorites/' .. SID .. '_enable') then
				setConfigVal('favorites/' .. SID .. '_enable',1)
			end

			if getConfigVal('favorites/' .. SID .. '_type') and tonumber(getConfigVal('favorites/' .. SID .. '_type')) > 3 then
				NameFavoriteTypeMedia = tname[tonumber(getConfigVal('favorites/' .. SID .. '_type'))-3]
			else
				NameFavoriteTypeMedia = '✔ ' .. NameTypeMedia
				setConfigVal('favorites/' .. SID .. '_type',TypeMedia)
			end

			t[i]={}
			t[i].Name=Name
			t[i].GroupName = NameTypeMedia
			t[i].Group = TypeMedia
			t[i].Action = SID
			t[i].InfoPanelLogo = Logo
			t[i].InfoPanelName = Name .. ' ' .. update
			t[i].InfoPanelTitle = desc
			t[i].InfoPanelShowTime = 10000
			if isEnable == 1 then
				t0[k0]={}
				t0[k0].FGroupName = NameFavoriteTypeMedia
				t0[k0].FGroup = getConfigVal('favorites/' .. SID .. '_type')
				t0[k0].Name=Name
				t0[k0].Action = SID
				t0[k0].InfoPanelLogo = Logo
				t0[k0].InfoPanelName = Name .. ' ' .. update
				t0[k0].InfoPanelTitle = desc
				t0[k0].InfoPanelShowTime = 10000
				k0 = k0 + 1
			end
			i = i + 1
		end

		m_simpleTV.User.TVSources_fav.fav = t0
		m_simpleTV.User.TVSources_fav.all = t

		table.sort(t, function(a, b) return tostring(a.Name) < tostring(b.Name) end)
		local str = ''
		for i = 1, #t do
			local str1 =
			[[		<tr>
			<td width="30"><img src="]]
			local str2 =
			[[" height="16" align="center"></td>
			<td width="150"><strong>]]
			local str3 =
			[[</strong></td>
			<td><input id="]]
			local str4 =
			[[_Enable" type="checkbox"/></td>
			<td width="220">
			    <select id="]]

			str = str .. '\n' .. str1 .. t[i].InfoPanelLogo:gsub('^%.%.','simpleTVImage:./work') .. str2 .. t[i].Name .. str3 .. t[i].Action .. str4 .. t[i].Action .. m_simpleTV.User.TVSources_fav.str

			i = i + 1
		end
local top_html1 =
[[
<HTML>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <style type="text/css">
#arcs-1, #arcs-2, #arcs-3 {
	transform-origin: center;
}
#arcs-1 {
	animation: arcs1 20s ease-in-out infinite;
}
#arcs-2 {
	animation: arcs2 25s ease-in-out infinite;
}
#arcs-3 {
	animation: arcs3 30s ease-in-out infinite;
}
@keyframes arcs1 {
	0% {
		transform: rotate(0deg);
	}
	10% {
		transform: rotate(120deg);
	}
	20% {
		transform: rotate(50deg);
	}
	30% {
		transform: rotate(180deg);
	}
	40% {
		transform: rotate(90deg);
	}
	50% {
		transform: rotate(340deg);
	}
	60% {
		transform: rotate(130deg);
	}
	70% {
		transform: rotate(280deg);
	}
	80% {
		transform: rotate(80deg);
	}
	90% {
		transform: rotate(320deg);
	}
	100% {
		transform: rotate(0deg);
	}
}
@keyframes arcs2 {
	0% {
		transform: rotate(0deg);
	}
	10% {
		transform: rotate(-120deg);
	}
	20% {
		transform: rotate(-50deg);
	}
	30% {
		transform: rotate(-180deg);
	}
	40% {
		transform: rotate(-90deg);
	}
	50% {
		transform: rotate(-340deg);
	}
	60% {
		transform: rotate(-130deg);
	}
	70% {
		transform: rotate(-280deg);
	}
	80% {
		transform: rotate(-80deg);
	}
	90% {
		transform: rotate(-320deg);
	}
	100% {
		transform: rotate(0deg);
	}
}
@keyframes arcs3 {
	0% {
		transform: rotate(0deg);
	}
	10% {
		transform: rotate(180deg);
	}
	20% {
		transform: rotate(90deg);
	}
	30% {
		transform: rotate(280deg);
	}
	40% {
		transform: rotate(30deg);
	}
	50% {
		transform: rotate(340deg);
	}
	60% {
		transform: rotate(130deg);
	}
	70% {
		transform: rotate(280deg);
	}
	80% {
		transform: rotate(80deg);
	}
	90% {
		transform: rotate(320deg);
	}
	100% {
		transform: rotate(0deg);
	}
}
#logo-link {
display:flex;
align-items: center;
margin-bottom: 10px;
}
#logo-link img {
margin-left: 10px;
}
* {
font-family:Geneva, Arial, Helvetica, sans-serif;
font-size:12px;
}

body {
background-color:#F0F0F0;
font-size:100%;
color:#42454a;

}

a,img {
border:none;
outline:none;
}


#desc {
padding-top:15px;
padding-left:0px;
padding-bottom:5px;
font-weight:700;
}

#bottom {
position:fixed;
bottom:0;
right:0;
width:200px;
color:#F0F0F0;;
background-color:#42454a;
text-align:center;
}

.outtext {
font-size: 12px;
width: 250px;
}
    </style>



  </head>
<body>
<a href = simpleTVLua:m_simpleTV.Interface.OpenLink('http://iptv.gen12.net/bugtracker/view.php?id=1741') title="Repository and discussion" id="logo-link">
	<svg viewBox="0 0 512 512" width="128" height="128" version="1.1" xmlns="http://www.w3.org/2000/svg">
		<defs>
			<linearGradient id="outer-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
				<stop offset="0%" style="stop-color:rgb(8,202,252);stop-opacity:1"/>
				<stop offset="100%" style="stop-color:rgb(0,73,88);stop-opacity:1"/>
			</linearGradient>
			<radialGradient id="inner-gradient" cx="50%" cy="50%" r="50%" fx="50%" fy="50%">
				<stop offset="0%" style="stop-color:rgb(2,195,245);stop-opacity:1"/>
				<stop offset="100%" style="stop-color:rgb(0,139,172);stop-opacity:1"/>
			</radialGradient>
		</defs>
		<circle id="outer-circle" cx="256" cy="256" r="190" fill="url(#outer-gradient)"/>
		<circle id="inner-circle" cx="256" cy="256" r="170" fill="url(#inner-gradient)" stroke-width="20" stroke="#000"/>
		<path d="M 406 256 A 150 150 0 0 0 106 256 Q108,330,200,270 Q256,236, 312 270 Q404,330,406 256" fill="#fff" opacity="0.35"/>
		<path id="arcs-1"
			  d="M 127.44247806269212 409.2088886237956 A 200 200 0 0 0 452.9615506024416 290.72963553338604 L 464.4346918446776 281.59256211508097 A 210 210 0 0 1 112.78034438687536 409.5842773400258 z M 384.55752193730785 102.79111137620438 A 200 200 0 0 0 59.038449397558395 221.2703644666139 L 47.565308155322384 230.40743788491898 A 210 210 0 0 1 399.2196556131246 102.41572265997408 z"
			  stroke="none" fill="#2a8fa9"/>
		<path id="arcs-2"
			  d="M 217.79740091327534 472.65770566268577 A 220 220 0 0 0 462.73237657289985 180.75556846835286 L 467.7161162940613 166.13184044746703 A 230 230 0 0 1 204.26125750091109 480.1051149006041 z M 294.2025990867246 39.3422943373142 A 220 220 0 0 0 49.267623427100176 331.24443153164714 L 44.28388370593876 345.86815955253303 A 230 230 0 0 1 307.7387424990889 31.894885099395907 z"
			  stroke="none" fill="#1f7284"/>
		<path id="arcs-3"
			  d="M 376 463.8460969082653 A 240 240 0 0 0 376 48.15390309173475 L 369.49762493488674 33.248368952908066 A 250 250 0 0 1 369.49762493488674 478.7516310470919 z M 135.9999999999999 48.153903091734776 A 240 240 0 0 0 136.00000000000006 463.8460969082653 L 142.5023750651133 478.75163104709196 A 250 250 0 0 1 142.50237506511326 33.248368952908066 z"
			  stroke="none" fill="#02C3F5"/>
		<path fill="#fff" d="M 190 176 A 11 11 0 0 1 206 166 L 335 246.625 A 11 11 0 0 1 335 265.375 L 206 346 A 11 11 0 0 1 190 336" fill-opacity="0.9"/>
	</svg>
	<img src="img/Logo SIMPLE-TVS Favorite1.svg" height="64">
</a>
<fieldset ><legend>]]

local top_html2 =
[[</legend>
	<table>
		<tr>
			<td width="30"></td>
			<td width="220"><label for="TVSFavoriteWS_Enable" title="]]

local top_html3 =
[[</strong></label></td>
			<td><input id="TVSFavoriteWS_Enable" type="checkbox"/></td>
			<td></td>
		</tr>
		<tr>
			<td width="30"></td>
			<td width="220"><label for="TVSFavoriteWS_Add" title="]]

local top_html4 =
[[</strong></label></td>
			<td><input id="TVSFavoriteWS_Add" type="checkbox"/></td>
		</tr>]]

local bottom_html =
[[	</table>
</fieldset>
</br>

<hr>
<div id="desc">Bugtracker WS Skins: <a href=simpleTVLua:m_simpleTV.Interface.OpenLink('http://iptv.gen12.net/bugtracker/view.php?id=1733')>http://iptv.gen12.net/bugtracker/view.php?id=1733</a>
<div id="desc">Bugtracker WS Portal: <a href=simpleTVLua:m_simpleTV.Interface.OpenLink('http://iptv.gen12.net/bugtracker/view.php?id=1741')>http://iptv.gen12.net/bugtracker/view.php?id=1741</a>
<div id="desc">GitHub WS: <a href=simpleTVLua:m_simpleTV.Interface.OpenLink('https://github.com/west-side-simple/Lite-Portal')>https://github.com/west-side-simple/Lite-Portal</a>
<div id="desc">GitHub BM (аддон TVSources): <a href=simpleTVLua:m_simpleTV.Interface.OpenLink('https://github.com/BMSimple/SimpleTV/releases/')>https://github.com/BMSimple/SimpleTV/releases/</a>
<p>
<hr>
<div id="desc">]]

	local filePath = m_simpleTV.MainScriptDir .. 'user/TVSources_fav/configdialog.html'
	local fhandle = io.open(filePath, 'w+')
	fhandle:write(top_html1 .. m_simpleTV.User.TVSources_fav.str5 .. top_html2 .. m_simpleTV.User.TVSources_fav.str6 .. '"><strong>' .. m_simpleTV.User.TVSources_fav.str6 .. top_html3 .. m_simpleTV.User.TVSources_fav.str7 .. '"><strong>' .. m_simpleTV.User.TVSources_fav.str7 .. top_html4 .. str .. bottom_html .. m_simpleTV.User.TVSources_fav.str8)
	fhandle:close()
else return end

	local function FavMenu3(cat,isfav)
		local t,tt,j = {},{},1
		if tonumber(isfav) == 0 then
			t = m_simpleTV.User.TVSources_fav.all
			table.sort(t, function(a, b) return tostring(a.Name) < tostring(b.Name) end)
			for i = 1, #t do
				if tonumber(t[i].Group) == tonumber(cat) then
					tt[j] = t[i]
					tt[j].Id = j
					j = j + 1
				end
				i = i + 1
			end
			tt.ExtButton0 = {ButtonEnable = true, ButtonName = '🢀'}
			local ret,id = m_simpleTV.OSD.ShowSelect_UTF8(tt[1].GroupName,0,tt,9000,1+4+8)
			if id == nil then return end
			if ret == 1 then
				tvs_func.OSD_mess(tt[1].GroupName .. ' 🔄 ' .. tt[id].Name )
				tvs_core.UpdateSource(tt[id].Action, true) -- процедура обновления источника
			end
			if ret == 2 then
			  FavMenu2()
			end
		else
			t = m_simpleTV.User.TVSources_fav.fav
			table.sort(t, function(a, b) return tostring(a.Name) < tostring(b.Name) end)
			for i = 1, #t do
				if tonumber(t[i].FGroup) == tonumber(cat) then
					tt[j] = t[i]
					tt[j].Id = j
					j = j + 1
				end
				i = i + 1
			end
			tt.ExtButton0 = {ButtonEnable = true, ButtonName = '🢀'}
			local ret,id = m_simpleTV.OSD.ShowSelect_UTF8(tt[1].FGroupName,0,tt,9000,1+4+8)
			if id == nil then return end
			if ret == 1 then
				tvs_func.OSD_mess(tt[1].FGroupName .. ' 🔄 ' .. tt[id].Name )
				tvs_core.UpdateSource(tt[id].Action, true) -- процедура обновления источника
			end
			if ret == 2 then
			  FavMenu1()
			end
		end
		tvs_func.OSD_mess('')
	end

	function FavMenu1()
		local t = m_simpleTV.User.TVSources_fav.fav
		local tt, item = {},1
		local t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,k0,k1,k2,k3,k4,k5,k6,k7,k8,k9 = {},{},{},{},{},{},{},{},{},{},1,1,1,1,1,1,1,1,1,1
		for i = 1, #t do
			if tonumber(t[i].FGroup) == 0 then
				t0[k0] = t[i]
				k0 = k0 + 1
			end
			if tonumber(t[i].FGroup) == 1 then
				t1[k1] = t[i]
				k1 = k1 + 1
			end
			if tonumber(t[i].FGroup) == 2 then
				t2[k2] = t[i]
				k2 = k2 + 1
			end
			if tonumber(t[i].FGroup) == 3 then
				t3[k3] = t[i]
				k3 = k3 + 1
			end
			if tonumber(t[i].FGroup) == 4 then
				t4[k4] = t[i]
				k4 = k4 + 1
			end
			if tonumber(t[i].FGroup) == 5 then
				t5[k5] = t[i]
				k5 = k5 + 1
			end
			if tonumber(t[i].FGroup) == 6 then
				t6[k6] = t[i]
				k6 = k6 + 1
			end
			if tonumber(t[i].FGroup) == 7 then
				t7[k7] = t[i]
				k7 = k7 + 1
			end
			if tonumber(t[i].FGroup) == 8 then
				t8[k8] = t[i]
				k8 = k8 + 1
			end
			if tonumber(t[i].FGroup) == 9 then
				t9[k9] = t[i]
				k9 = k9 + 1
			end
			i = i + 1
		end
		if #t0 > 0 then
			tt[item] = {}
			tt[item].Id = item
			tt[item].Name = t0[1].FGroupName .. ' (' .. #t0 .. ')'
			tt[item].Action = 0
			item = item + 1
		end
		if #t1 > 0 then
			tt[item] = {}
			tt[item].Id = item
			tt[item].Name = t1[1].FGroupName .. ' (' .. #t1 .. ')'
			tt[item].Action = 1
			item = item + 1
		end
		if #t2 > 0 then
			tt[item] = {}
			tt[item].Id = item
			tt[item].Name = t2[1].FGroupName .. ' (' .. #t2 .. ')'
			tt[item].Action = 2
			item = item + 1
		end
		if #t3 > 0 then
			tt[item] = {}
			tt[item].Id = item
			tt[item].Name = t3[1].FGroupName .. ' (' .. #t3 .. ')'
			tt[item].Action = 3
			item = item + 1
		end
		if #t4 > 0 then
			tt[item] = {}
			tt[item].Id = item
			tt[item].Name = t4[1].FGroupName .. ' (' .. #t4 .. ')'
			tt[item].Action = 4
			item = item + 1
		end
		if #t5 > 0 then
			tt[item] = {}
			tt[item].Id = item
			tt[item].Name = t5[1].FGroupName .. ' (' .. #t5 .. ')'
			tt[item].Action = 5
			item = item + 1
		end
		if #t6 > 0 then
			tt[item] = {}
			tt[item].Id = item
			tt[item].Name = t6[1].FGroupName .. ' (' .. #t6 .. ')'
			tt[item].Action = 6
			item = item + 1
		end
		if #t7 > 0 then
			tt[item] = {}
			tt[item].Id = item
			tt[item].Name = t7[1].FGroupName .. ' (' .. #t7 .. ')'
			tt[item].Action = 7
			item = item + 1
		end
		if #t8 > 0 then
			tt[item] = {}
			tt[item].Id = item
			tt[item].Name = t8[1].FGroupName .. ' (' .. #t8 .. ')'
			tt[item].Action = 8
			item = item + 1
		end
		if #t9 > 0 then
			tt[item] = {}
			tt[item].Id = item
			tt[item].Name = t9[1].FGroupName .. ' (' .. #t9 .. ')'
			tt[item].Action = 9
		end

		tt.ExtButton0 = {ButtonEnable = true, ButtonName = '🢀'}
		local ret,id = m_simpleTV.OSD.ShowSelect_UTF8(m_simpleTV.User.TVSources_fav.str2,0,tt,9000,1+4+8)
		if id == nil then return end
		if ret == 1 then
			FavMenu3(tt[id].Action,1)
		end
		if ret == 2 then
		  favorite_scrapers()
		end
	end

	function FavMenu2()
		local t = m_simpleTV.User.TVSources_fav.all
		local tt, item = {},1
		local t0,t1,t2,t3,k0,k1,k2,k3 = {},{},{},{},1,1,1,1
		for i = 1, #t do
			if tonumber(t[i].Group) == 0 then
				t0[k0] = t[i]
				k0 = k0 + 1
			end
			if tonumber(t[i].Group) == 1 then
				t1[k1] = t[i]
				k1 = k1 + 1
			end
			if tonumber(t[i].Group) == 2 then
				t2[k2] = t[i]
				k2 = k2 + 1
			end
			if tonumber(t[i].Group == 3) then
				t3[k3] = t[i]
				k3 = k3 + 1
			end
			i = i + 1
		end
		if #t0 > 0 then
			tt[item] = {}
			tt[item].Id = item
			tt[item].Name = t0[1].GroupName .. ' (' .. #t0 .. ')'
			tt[item].Action = 0
			item = item + 1
		end
		if #t1 > 0 then
			tt[item] = {}
			tt[item].Id = item
			tt[item].Name = t1[1].GroupName .. ' (' .. #t1 .. ')'
			tt[item].Action = 1
			item = item + 1
		end
		if #t2 > 0 then
			tt[item] = {}
			tt[item].Id = item
			tt[item].Name = t2[1].GroupName .. ' (' .. #t2 .. ')'
			tt[item].Action = 2
			item = item + 1
		end
		if #t3 > 0 then
			tt[item] = {}
			tt[item].Id = item
			tt[item].Name = t3[1].GroupName .. ' (' .. #t3 .. ')'
			tt[item].Action = 3
		end
		if m_simpleTV.User.TVSources_fav.Add == 1 then
			tt.ExtButton0 = {ButtonEnable = true, ButtonName = '🢀'}
		end
		local ret,id = m_simpleTV.OSD.ShowSelect_UTF8(m_simpleTV.User.TVSources_fav.str3,0,tt,9000,1+4+8)
		if id == nil then return end
		if ret == 1 then
			FavMenu3(tt[id].Action,0)
		end
		if ret == 2 then
		  favorite_scrapers()
		end
	end

	function favorite_scrapers()
		m_simpleTV.Control.ExecuteAction(37)
		if tonumber(m_simpleTV.User.TVSources_fav.Enable) == 1 then
		local t = {}
				t[1] = {}
				t[1].Id = 1
				t[1].Name = m_simpleTV.User.TVSources_fav.str2 .. ' (' .. #m_simpleTV.User.TVSources_fav.fav .. ')'
				t[2] = {}
				t[2].Id = 2
				t[2].Name = m_simpleTV.User.TVSources_fav.str3 .. ' (' .. #m_simpleTV.User.TVSources_fav.all .. ')'

		local ret,id = m_simpleTV.OSD.ShowSelect_UTF8(m_simpleTV.User.TVSources_fav.str1,0,t,9000,1+4+8)
		if id==nil then return end
		if ret==1 then
			if id == 1 then
				FavMenu1()
			else
				FavMenu2()
			end
		end
		else
			FavMenu2()
		end
	end

	local tt={}
	tt.utf8 = true
	tt.name = m_simpleTV.User.TVSources_fav.str0
	tt.luastring = 'favorite_scrapers()'
	tt.lua_as_scr = true
	tt.key = string.byte('M')
	tt.ctrlkey = 3
	tt.location = 0
	tt.image= m_simpleTV.MainScriptDir_UTF8 .. 'user/TVSources/settings/img/TVSourcesButtonC.png'

	if tonumber(m_simpleTV.User.TVSources_fav.Enable) == 1 and m_simpleTV.User.TVSources_fav.ini == nil then		
		m_simpleTV.Interface.AddExtMenuT(tt)
	end
