-- ini for TVSources Fav WS plugin
-- author west_side 03.08.23
	m_simpleTV.User.TVSources_fav.ini = true
	local t ={}
		t.name = m_simpleTV.User.TVSources_fav.str4
		t.htmlUri = m_simpleTV.MainScriptDir_UTF8 .. 'user/TVSources_fav/configDialog.html'
		t.luaUri  = 'user/TVSources_fav/configDialog.lua'
		t.iconUri  = m_simpleTV.MainScriptDir_UTF8 .. 'user/TVSources/settings/img/TVSourcesButtonC.png'

	m_simpleTV.Config.AddExtDialogT(t)