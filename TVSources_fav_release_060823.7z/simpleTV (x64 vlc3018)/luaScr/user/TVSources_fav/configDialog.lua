-- config for dialog window TVS Favorite plugin
-- author west_side 06.08.23

	if m_simpleTV.User==nil then m_simpleTV.User={} end
	if m_simpleTV.User.TVSources_fav==nil then m_simpleTV.User.TVSources_fav={} end

	local function getConfigVal(key)
		return m_simpleTV.Config.GetValue(key,'TVS.ini')
	end

	local function setConfigVal(key,val)
		m_simpleTV.Config.SetValue(key,val,'TVS.ini')
	end

	local function GetComboValue(value)
		local tname
		if m_simpleTV.Interface.GetLanguage() == 'ru' then
			tname = {'Телевидение', 'Видеобиблиотека', 'Стримы', 'Аудиокниги', 'Радио', 'Платные $'}
		else
			tname = {'TV', 'VideoLibrary', 'Streams', 'Audiobooks', 'Radio', 'Paid $'}
		end
		for i = 1,#tname do
			if tname[i] == value then
				return i + 3
			end
			i = i + 1
		end
		return 0
	end

	function OnNavigateComplete(Object)

		local value

		value= getConfigVal('favorites_general/TVSFavoriteWS_Enable') or 1
		m_simpleTV.Dialog.SetCheckBoxValue(Object,'TVSFavoriteWS_Enable',value)

		value= getConfigVal('favorites_general/TVSFavoriteWS_Add') or 1
		m_simpleTV.Dialog.SetCheckBoxValue(Object,'TVSFavoriteWS_Add',value)

		value= getConfigVal('favorites_general/TVSFavoriteWS_Combo') or 1
		m_simpleTV.Dialog.SetCheckBoxValue(Object,'TVSFavoriteWS_Combo',value)

		if m_simpleTV.User.TVSources_fav.all and #m_simpleTV.User.TVSources_fav.all and #m_simpleTV.User.TVSources_fav.all > 0 then
			local t = m_simpleTV.User.TVSources_fav.all
			for i = 1,#t do
				local value1 = getConfigVal('favorites/' .. t[i].Action .. '_enable') or 1
				m_simpleTV.Dialog.SetCheckBoxValue(Object,t[i].Action .. '_Enable',value1)

				local value2 = getConfigVal('favorites/' .. t[i].Action .. '_type') or 0
				if tonumber(value2) <= 3 then
					value2 = 0
				else
					value2 = tonumber(value2) - 3
				end
				m_simpleTV.Dialog.SelectComboIndex(Object,t[i].Action .. '_Select',value2)
				i = i + 1
			end
		end
	end

	function OnOk(Object)

		local value

		value=m_simpleTV.Dialog.GetCheckBoxValue(Object,'TVSFavoriteWS_Enable')
		if value ~= nil then
			setConfigVal('favorites_general/TVSFavoriteWS_Enable',value)
			m_simpleTV.User.TVSources_fav.Enable = 1
			if tonumber(value) == 0 then
				m_simpleTV.User.TVSources_fav.Enable = 0
			end
		end

		value=m_simpleTV.Dialog.GetCheckBoxValue(Object,'TVSFavoriteWS_Add')
		if value ~= nil then
			setConfigVal('favorites_general/TVSFavoriteWS_Add',value)
			m_simpleTV.User.TVSources_fav.Add = 1
			if tonumber(value) == 0 then
				m_simpleTV.User.TVSources_fav.Add = 0
			end
		end

		value=m_simpleTV.Dialog.GetCheckBoxValue(Object,'TVSFavoriteWS_Combo')
		if value ~= nil then
			setConfigVal('favorites_general/TVSFavoriteWS_Combo',value)
			m_simpleTV.User.TVSources_fav.Combo = 1
			if tonumber(value) == 0 then
				m_simpleTV.User.TVSources_fav.Combo = 0
			end
		end

		if m_simpleTV.User.TVSources_fav.all and #m_simpleTV.User.TVSources_fav.all and #m_simpleTV.User.TVSources_fav.all > 0 then
			local t = m_simpleTV.User.TVSources_fav.all
			for i = 1,#t do
				local value1 = m_simpleTV.Dialog.GetCheckBoxValue(Object,t[i].Action .. '_Enable')
				if value1 ~= nil then
					setConfigVal('favorites/' .. t[i].Action .. '_enable',value1)
				end

				local value2 = m_simpleTV.Dialog.GetComboValue_UTF8(Object,t[i].Action .. '_Select')
				if value1 ~= nil then
					if value2 == '' then
						setConfigVal('favorites/' .. t[i].Action .. '_type',0)
					else value2 = GetComboValue(value2)
						setConfigVal('favorites/' .. t[i].Action .. '_type',value2)
					end
				end
				i = i + 1
			end
			dofile(m_simpleTV.MainScriptDir .. 'user/startup/TVSources_fav.lua')
		end
	end
